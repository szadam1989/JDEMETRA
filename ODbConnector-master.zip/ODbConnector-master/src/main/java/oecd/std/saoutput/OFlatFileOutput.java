/*
 * Copyright 2013 National Bank of Belgium
 *
 * Licensed under the EUPL, Version 1.1 or – as soon they will be approved 
 * by the European Commission - subsequent versions of the EUPL (the "Licence");
 * You may not use this work except in compliance with the Licence.
 * You may obtain a copy of the Licence at:
 *
 * http://ec.europa.eu/idabc/eupl
 *
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the Licence is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the Licence for the specific language governing permissions and 
 * limitations under the Licence.
 */
package oecd.std.saoutput;

import ec.satoolkit.ISaSpecification;
import ec.tss.sa.documents.SaDocument;
import ec.tss.sa.output.BasicConfiguration;
import ec.tss.tsproviders.utils.MultiLineNameUtil;
import ec.tstoolkit.algorithm.IOutput;
import ec.tstoolkit.timeseries.simplets.TsData;
import ec.tstoolkit.utilities.LinearId;
import ec.tstoolkit.utilities.Paths;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import org.openide.util.Exceptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Kristof Bayens
 * @author Gyorgy Gyomai
 */
public class OFlatFileOutput extends BasicConfiguration implements IOutput<SaDocument<ISaSpecification>> {

    public static final Logger LOGGER = LoggerFactory.getLogger(OFlatFileOutputFactory.class);
    private OFlatFileConfiguration config_;
    private File folder;
    private OutputStreamWriter w;

    public OFlatFileOutput(OFlatFileConfiguration config) {
        config_ = config.clone();
    }

    @Override
    public void process(SaDocument<ISaSpecification> document) throws Exception {
        if (document.getResults() == null) {
            return;
        }
        String sname = document.getInput().getName();
//        if (config_.isFullName()) {
//            sname = MultiLineNameUtil.join(sname, " * ");
//        } else {
//            sname = MultiLineNameUtil.last(sname);
//        }
        sname = sname.replaceAll(",\\s*", "-");
        sname = sname.replaceAll("[\\s*]\\[frozen\\]", "");
        
        for (String item : config_.getSeries()) {
            TsData s = document.getResults().getData(item, TsData.class);
            if (s != null) {
                write(w,s,sname +"-" + item);
            }
        }
    }

    @Override
    public void start(Object context) {
        
        folder = BasicConfiguration.folderFromContext(config_.getFolder(), context);
        File file = new File(folder, Paths.changeExtension(((LinearId)context).get(1), "csv")); //context.data_[1] of type LinearId
             System.out.println(context.getClass().getName());
        try {w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8);
        } catch (FileNotFoundException ex) {
            Exceptions.printStackTrace(ex);
        }
}

    @Override
    public void end(Object file) throws IOException {
        w.close();
    }

    @Override
    public String getName() {
        return "csv";
    }

    @Override
    public boolean isAvailable() {
        return true;
    }

    public static void write(OutputStreamWriter writeTo, TsData series, String seriesName) throws Exception {
        if (series == null) {
            return;
        }
        String freq; 
        switch (series.getFrequency().intValue()) {
            case 1:  freq = "Y";
                     break;
            case 3:  freq = "Q";
                     break;
            case 12:  freq = "M";
                     break;
            default: freq = "Not handled periodicity";
                     break;
        }
        
        for (int i = 0; i < series.getLength(); ++i) {
                writeTo.write(seriesName);
                writeTo.write(",");
                writeTo.write(Integer.toString(series.getDomain().get(i).getYear()));
                writeTo.write(",");
                writeTo.write(freq);
                writeTo.write(",");
                writeTo.write(Integer.toString(series.getDomain().get(i).getPosition()+1));
                writeTo.write(",");
                double value = series.get(i);
                writeTo.write(Double.toString(Double.isNaN(value) ? -999999999 : value));
                writeTo.write("\r\n");
            }
        }
}
